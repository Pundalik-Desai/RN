import React, { useState, useRef } from 'react';
import { StyleSheet, View, Text, Button, TouchableOpacity, FlatList, Alert } from 'react-native';
import Constants from 'expo-constants';

// Simple clipboard support for Snack (works in Expo web & devices)
import * as Clipboard from 'expo-clipboard';

const copyToClipboard = async (text) => {
  try {
    if (!text) {
      Alert.alert('Nothing to copy');
      return;
    }
    await Clipboard.setStringAsync(text);
    Alert.alert('Copied', text);
  } catch (err) {
    console.warn('Copy failed', err);
    Alert.alert('Copy failed');
  }
};

/* Generators */

// Numeric OTP
const generateNumericCode = (length = 6) => {
  let code = '';
  for (let i = 0; i < length; i++) {
    code += Math.floor(Math.random() * 10).toString();
  }
  return code;
};

// Alphanumeric
const generateAlphaNumeric = (length = 8) => {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let code = '';
  for (let i = 0; i < length; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
};

// Readable segmented code
const generateReadableCode = (segments = 3, segLength = 4, separator = '-') => {
  const chars = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  const segs = [];
  for (let s = 0; s < segments; s++) {
    let seg = '';
    for (let i = 0; i < segLength; i++) {
      seg += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    segs.push(seg);
  }
  return segs.join(separator);
};

// UUID v4
const generateUUIDv4 = () =>
  'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });

// Unique generator (in-memory)
const generateUnique = (generatorFn, existingSet, ...args) => {
  let attempt = 0;
  let code;
  do {
    if (++attempt > 1000) throw new Error('Too many attempts to generate unique code');
    code = generatorFn(...args);
  } while (existingSet.has(code));
  existingSet.add(code);
  return code;
};

export default function App() {
  const [lastCode, setLastCode] = useState('');
  const [history, setHistory] = useState([]);
  const existing = useRef(new Set());

  const addToHistory = (code, type) => {
    const item = { id: Date.now().toString() + Math.random().toString(36).slice(2, 7), code, type };
    setHistory((h) => [item, ...h].slice(0, 50));
  };

  const onGenerate = (mode) => {
    try {
      let code;
      switch (mode) {
        case 'numeric':
          code = generateUnique(generateNumericCode, existing.current, 6);
          break;
        case 'alpha':
          code = generateUnique(generateAlphaNumeric, existing.current, 8);
          break;
        case 'readable':
          code = generateUnique(generateReadableCode, existing.current, 3, 4, '-');
          break;
        case 'uuid':
          code = generateUnique(generateUUIDv4, existing.current);
          break;
        default:
          code = generateAlphaNumeric(8);
      }
      setLastCode(code);
      addToHistory(code, mode);
    } catch (err) {
      Alert.alert('Error', err.message || 'Could not generate code');
    }
  };

  const handleCopy = async (text) => {
    await copyToClipboard(text);
  };

  const renderItem = ({ item }) => (
    <View style={styles.item}>
      <View style={{ flex: 1 }}>
        <Text style={styles.code}>{item.code}</Text>
        <Text style={styles.type}>{item.type}</Text>
      </View>
      <TouchableOpacity style={styles.smallBtn} onPress={() => handleCopy(item.code)}>
        <Text style={styles.smallBtnText}>Copy</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Code Generator</Text>
      <Text style={{fontSize:12,color:'#666', marginBottom:6}}>Expo Snack - Demo (SDK {Constants.manifest?.sdkVersion || 'managed'})</Text>

      <View style={styles.buttonsRow}>
        <Button title="Numeric (OTP)" onPress={() => onGenerate('numeric')} />
        <Button title="Alphanumeric" onPress={() => onGenerate('alpha')} />
      </View>

      <View style={styles.buttonsRow}>
        <Button title="Readable (XXXX-XXXX)" onPress={() => onGenerate('readable')} />
        <Button title="UUID v4" onPress={() => onGenerate('uuid')} />
      </View>

      <View style={styles.resultBox}>
        <Text style={styles.resultLabel}>Last Generated:</Text>
        <Text selectable style={styles.lastCode}>
          {lastCode || '-'}
        </Text>

        <View style={{ flexDirection: 'row', gap: 10, marginTop: 8 }}>
          <TouchableOpacity
            style={[styles.actionBtn, { backgroundColor: '#2f95dc' }]}
            onPress={() => handleCopy(lastCode)}
            disabled={!lastCode}
          >
            <Text style={styles.actionTxt}>Copy</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.actionBtn, { backgroundColor: '#4caf50' }]}
            onPress={() => {
              if (lastCode) {
                Alert.alert('Use this code', lastCode);
              } else {
                Alert.alert('No code', 'Generate a code first');
              }
            }}
          >
            <Text style={styles.actionTxt}>Use</Text>
          </TouchableOpacity>
        </View>
      </View>

      <Text style={styles.historyTitle}>History</Text>
      <FlatList data={history} keyExtractor={(i) => i.id} renderItem={renderItem} style={{ width: '100%' }} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: 'center', padding: 16, backgroundColor: '#fff', paddingTop: 40 },
  title: { fontSize: 20, fontWeight: '700', marginBottom: 8 },
  buttonsRow: { flexDirection: 'row', width: '100%', justifyContent: 'space-between', marginVertical: 6 },
  resultBox: {
    width: '100%',
    marginTop: 14,
    marginBottom: 8,
    padding: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#eee',
  },
  resultLabel: { color: '#666', marginBottom: 6 },
  lastCode: { fontSize: 24, fontWeight: '700', marginBottom: 8 },
  actionBtn: {
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 6,
    marginVertical: 4,
  },
  actionTxt: { color: '#fff', fontWeight: '600' },
  historyTitle: { fontSize: 16, fontWeight: '600', marginTop: 12, alignSelf: 'flex-start' },
  item: {
    width: '100%',
    padding: 10,
    borderBottomWidth: 1,
    borderColor: '#f0f0f0',
    flexDirection: 'row',
    alignItems: 'center',
  },
  code: { fontSize: 16, fontWeight: '600' },
  type: { color: '#777', fontSize: 12 },
  smallBtn: { backgroundColor: '#ddd', padding: 8, borderRadius: 6 },
  smallBtnText: { fontWeight: '600' },
});